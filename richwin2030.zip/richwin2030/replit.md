# RICHWIN 2030 - Personal Dashboard Application

## Overview
A React-based personal dashboard application for tracking life goals, memories, achievements, and progress toward 2030 vision. Built with modern technologies and designed for a couple (Richmond & Edwina) to manage their shared journey.

## Project Architecture
- **Frontend**: React 18 + TypeScript + Vite
- **UI Framework**: shadcn/ui + Tailwind CSS
- **Routing**: React Router DOM
- **State Management**: React Query (TanStack Query)
- **Backend/Database**: Supabase
- **Deployment Target**: Static site (autoscale)

## Current State
- ✅ Application successfully running on port 5000
- ✅ Vite dev server configured for Replit environment
- ✅ Supabase integration configured
- ✅ All UI components properly structured
- ✅ Deployment configuration set up

## Key Features
- Dual user system (Richmond/Edwina)
- Dashboard with multiple life tracking sections:
  - Vision & Goals
  - Memories & Photos
  - Achievements
  - Finance tracking
  - Personal growth
  - Faith journey
  - Reading progress
  - Check-ins & legacy

## Development Setup
- Port 5000 (frontend)
- Host: 0.0.0.0 with allowedHosts: true for Replit proxy
- Environment variables configured for Supabase connection

## Recent Changes (September 14, 2025)
- Configured Vite for Replit environment (port 5000, host 0.0.0.0, allowedHosts: true)
- Set up workflow for development server
- Configured deployment for autoscale target
- Verified application functionality
- **Major UI Restructuring:**
  - **Vision & Goals Page**: Removed weekly to-do list functionality and restructured to display 1-Year, 3-Year, 5-Year, and 10-Year goals in a 4-column layout. Goals now default to the selected timeframe when adding new ones.
  - **Check-ins & Tasks Page**: Completely redesigned from relationship check-ins to a comprehensive 3-column task management system:
    - Daily To-Do List (left): Quick tasks categorized by work/study/personal
    - Weekly Priorities (center): "Big 5" goals with progress tracking and enforced 5-item limit
    - Review & Reflect (right): Weekly reflection with automatic unfinished item tracking and "move to next week" functionality
  - Added localStorage persistence for all task data to survive page refreshes

## User Preferences
- Uses TypeScript throughout
- Modern React patterns with hooks
- Comprehensive UI component library (shadcn/ui)
- Form handling with react-hook-form + zod validation
- Responsive design with Tailwind CSS