import React, { useState, useEffect } from 'react';
import { Heart, Infinity, Calendar } from 'lucide-react';
import coupleImage from "/lovable-uploads/40acfd79-440a-4b3d-b571-00e1938ddc1c.png";

export default function DayCounter() {
  const [timeData, setTimeData] = useState({
    days: 32,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  useEffect(() => {
    const updateTime = () => {
      const startDate = new Date('2025-08-08T00:00:00');
      const now = new Date();
      const timeDiff = now.getTime() - startDate.getTime();
      
      const days = Math.floor(timeDiff / (1000 * 3600 * 24));
      const hours = Math.floor((timeDiff % (1000 * 3600 * 24)) / (1000 * 3600));
      const minutes = Math.floor((timeDiff % (1000 * 3600)) / (1000 * 60));
      const seconds = Math.floor((timeDiff % (1000 * 60)) / 1000);
      
      setTimeData({ days, hours, minutes, seconds });
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative overflow-hidden rounded-3xl mx-4 mb-8 backdrop-blur-lg bg-gradient-to-br from-white/10 via-white/5 to-transparent border border-white/20 shadow-2xl shadow-primary/10">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url(${coupleImage})`,
          filter: 'blur(1px) brightness(0.3)'
        }}
      />
      
      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/30 via-primary/20 to-primary/40" />
      
      {/* Content */}
      <div className="relative z-10 px-8 py-10">
        {/* Header Section */}
        <div className="text-center mb-8">
          {/* Couple Image Circle */}
          <div className="relative mx-auto mb-6 w-24 h-24">
            <div className="absolute inset-0 rounded-full bg-gradient-to-br from-primary to-primary/70 p-1 shadow-lg shadow-primary/30">
              <img 
                src={coupleImage} 
                alt="Richmond & Edwina" 
                className="w-full h-full rounded-full object-cover border-2 border-white/30"
              />
            </div>
            {/* Floating Hearts */}
            <Heart className="absolute -top-2 -right-2 h-6 w-6 text-red-400 animate-pulse drop-shadow-lg" />
            <Heart className="absolute -bottom-1 -left-1 h-4 w-4 text-pink-400 animate-pulse drop-shadow-lg" style={{ animationDelay: '0.5s' }} />
          </div>
          
          <h2 className="text-3xl font-bold text-white mb-2 drop-shadow-lg">
            Our Love Story
          </h2>
          <p className="text-white/80 text-sm font-medium">
            Together since August 8, 2025
          </p>
        </div>

        {/* Timer Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-2xl mx-auto mb-8">
          {[
            { value: timeData.days, label: 'Days', gradient: 'from-rose-400 to-pink-600' },
            { value: timeData.hours, label: 'Hours', gradient: 'from-purple-400 to-purple-600' },
            { value: timeData.minutes, label: 'Minutes', gradient: 'from-blue-400 to-blue-600' },
            { value: timeData.seconds, label: 'Seconds', gradient: 'from-teal-400 to-emerald-600' }
          ].map((item, index) => (
            <div key={item.label} className="text-center">
              <div className={`relative p-4 rounded-2xl bg-gradient-to-br ${item.gradient} shadow-lg shadow-black/20 border border-white/20 backdrop-blur-sm`}>
                <div className="text-4xl md:text-5xl font-bold text-white mb-1 tracking-tight">
                  {item.value.toString().padStart(2, '0')}
                </div>
                <div className="text-xs md:text-sm text-white/90 font-medium uppercase tracking-wider">
                  {item.label}
                </div>
                {/* Shimmer Effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -skew-x-12 transform translate-x-[-100%] animate-pulse rounded-2xl" 
                     style={{ animationDelay: `${index * 0.5}s` }} />
              </div>
            </div>
          ))}
        </div>

        {/* Forever Message */}
        <div className="text-center">
          <div className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-white/10 backdrop-blur-sm border border-white/20">
            <Calendar className="h-5 w-5 text-white/80" />
            <span className="text-white font-medium">And we will be together</span>
            <Infinity className="h-6 w-6 text-yellow-300 animate-pulse drop-shadow-lg" />
            <span className="text-white font-medium">Forever</span>
          </div>
        </div>
      </div>

      {/* Floating Hearts Animation */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[...Array(6)].map((_, i) => (
          <Heart 
            key={i}
            className={`absolute text-white/20 animate-bounce`}
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${i * 2}s`,
              animationDuration: `${8 + i}s`
            }}
            size={12 + (i % 3) * 4}
          />
        ))}
      </div>
    </div>
  );
}