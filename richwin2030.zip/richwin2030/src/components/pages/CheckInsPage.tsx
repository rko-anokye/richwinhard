import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus, Edit2, Trash2, Calendar, CheckCircle, Clock, Target, BookOpen, Star } from "lucide-react";

interface DailyTask {
  id: string;
  title: string;
  category: 'work' | 'study' | 'personal';
  completed: boolean;
  date: string;
}

interface WeeklyPriority {
  id: string;
  title: string;
  description?: string;
  progress: number;
  completed: boolean;
  weekOf: string;
}

interface WeeklyReflection {
  id: string;
  weekOf: string;
  accomplishments: string;
  challenges: string;
  lessons: string;
  nextWeekFocus: string;
  unfinishedItems: string[];
}

export default function CheckInsPage() {
  const [dailyTasks, setDailyTasks] = useState<DailyTask[]>([]);
  const [weeklyPriorities, setWeeklyPriorities] = useState<WeeklyPriority[]>([]);
  const [weeklyReflection, setWeeklyReflection] = useState<WeeklyReflection | null>(null);

  // Load data from localStorage on component mount
  useEffect(() => {
    const savedDailyTasks = localStorage.getItem('dailyTasks');
    const savedWeeklyPriorities = localStorage.getItem('weeklyPriorities');
    const savedWeeklyReflection = localStorage.getItem('weeklyReflection');

    if (savedDailyTasks) {
      setDailyTasks(JSON.parse(savedDailyTasks));
    }
    if (savedWeeklyPriorities) {
      setWeeklyPriorities(JSON.parse(savedWeeklyPriorities));
    }
    if (savedWeeklyReflection) {
      setWeeklyReflection(JSON.parse(savedWeeklyReflection));
    }
  }, []);

  // Save to localStorage whenever state changes
  useEffect(() => {
    localStorage.setItem('dailyTasks', JSON.stringify(dailyTasks));
  }, [dailyTasks]);

  useEffect(() => {
    localStorage.setItem('weeklyPriorities', JSON.stringify(weeklyPriorities));
  }, [weeklyPriorities]);

  useEffect(() => {
    if (weeklyReflection) {
      localStorage.setItem('weeklyReflection', JSON.stringify(weeklyReflection));
    }
  }, [weeklyReflection]);

  // Form states
  const [newDailyTask, setNewDailyTask] = useState('');
  const [newDailyCategory, setNewDailyCategory] = useState<'work' | 'study' | 'personal'>('work');
  const [newWeeklyPriority, setNewWeeklyPriority] = useState('');
  const [newWeeklyDescription, setNewWeeklyDescription] = useState('');
  const [reflectionForm, setReflectionForm] = useState({
    accomplishments: '',
    challenges: '',
    lessons: '',
    nextWeekFocus: '',
  });

  const getCurrentDate = () => new Date().toISOString().split('T')[0];
  const getCurrentWeek = () => {
    const now = new Date();
    const monday = new Date(now.setDate(now.getDate() - now.getDay() + 1));
    return monday.toISOString().split('T')[0];
  };

  // Daily Tasks Functions
  const addDailyTask = () => {
    if (!newDailyTask.trim()) return;
    
    const task: DailyTask = {
      id: Date.now().toString(),
      title: newDailyTask,
      category: newDailyCategory,
      completed: false,
      date: getCurrentDate(),
    };
    
    setDailyTasks(prev => [...prev, task]);
    setNewDailyTask('');
  };

  const toggleDailyTask = (id: string) => {
    setDailyTasks(prev =>
      prev.map(task =>
        task.id === id ? { ...task, completed: !task.completed } : task
      )
    );
  };

  const deleteDailyTask = (id: string) => {
    setDailyTasks(prev => prev.filter(task => task.id !== id));
  };

  // Weekly Priorities Functions
  const addWeeklyPriority = () => {
    if (!newWeeklyPriority.trim()) return;
    
    // Enforce Big 5 limit
    const currentWeekPriorities = getCurrentWeekPriorities();
    if (currentWeekPriorities.length >= 5) {
      alert('You can only have 5 priorities per week. Focus on your Big 5!');
      return;
    }
    
    const priority: WeeklyPriority = {
      id: Date.now().toString(),
      title: newWeeklyPriority,
      description: newWeeklyDescription,
      progress: 0,
      completed: false,
      weekOf: getCurrentWeek(),
    };
    
    setWeeklyPriorities(prev => [...prev, priority]);
    setNewWeeklyPriority('');
    setNewWeeklyDescription('');
  };

  const updatePriorityProgress = (id: string, progress: number) => {
    setWeeklyPriorities(prev =>
      prev.map(priority =>
        priority.id === id ? { ...priority, progress, completed: progress === 100 } : priority
      )
    );
  };

  const deleteWeeklyPriority = (id: string) => {
    setWeeklyPriorities(prev => prev.filter(priority => priority.id !== id));
  };

  // Weekly Reflection Functions
  const saveReflection = () => {
    const reflection: WeeklyReflection = {
      id: Date.now().toString(),
      weekOf: getCurrentWeek(),
      accomplishments: reflectionForm.accomplishments,
      challenges: reflectionForm.challenges,
      lessons: reflectionForm.lessons,
      nextWeekFocus: reflectionForm.nextWeekFocus,
      unfinishedItems: weeklyPriorities
        .filter(p => !p.completed)
        .map(p => p.title),
    };
    
    setWeeklyReflection(reflection);
    
    // Reset reflection form
    setReflectionForm({
      accomplishments: '',
      challenges: '',
      lessons: '',
      nextWeekFocus: '',
    });
  };

  const moveUnfinishedToNextWeek = () => {
    const unfinishedPriorities = getCurrentWeekPriorities().filter(p => !p.completed);
    
    if (unfinishedPriorities.length === 0) {
      alert('No unfinished priorities to move.');
      return;
    }

    // Calculate next Monday
    const nextWeek = new Date();
    nextWeek.setDate(nextWeek.getDate() + (7 - nextWeek.getDay() + 1));
    const nextWeekString = nextWeek.toISOString().split('T')[0];

    // Create new priorities for next week
    const nextWeekPriorities = unfinishedPriorities.map(priority => ({
      ...priority,
      id: Date.now().toString() + Math.random(), // Ensure unique ID
      weekOf: nextWeekString,
      progress: 0, // Reset progress
      completed: false
    }));

    // Add to weekly priorities
    setWeeklyPriorities(prev => [...prev, ...nextWeekPriorities]);
    
    // Mark current week priorities as completed to clear them
    setWeeklyPriorities(prev => 
      prev.map(priority => 
        unfinishedPriorities.some(uf => uf.id === priority.id)
          ? { ...priority, completed: true, progress: 100 }
          : priority
      )
    );

    alert(`Moved ${unfinishedPriorities.length} unfinished priorities to next week!`);
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'work': return 'bg-blue-100 text-blue-800';
      case 'study': return 'bg-green-100 text-green-800';
      case 'personal': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTodaysTasks = () => {
    const today = getCurrentDate();
    return dailyTasks.filter(task => task.date === today);
  };

  const getCurrentWeekPriorities = () => {
    const currentWeek = getCurrentWeek();
    return weeklyPriorities.filter(priority => priority.weekOf === currentWeek);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold romantic-heading">Check-ins & Tasks</h1>
        <p className="text-lg text-muted-foreground">Stay organized and reflect on your progress</p>
      </div>

      {/* Three Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Column 1: Daily To-Do List */}
        <Card className="glass-card">
          <CardHeader>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-primary" />
              <CardTitle className="text-lg">Daily To-Do List</CardTitle>
            </div>
            <CardDescription>Quick tasks for today</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Add new task form */}
            <div className="space-y-3">
              <Input
                placeholder="Add a new task..."
                value={newDailyTask}
                onChange={(e) => setNewDailyTask(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && addDailyTask()}
                data-testid="input-new-daily-task"
              />
              <div className="flex gap-2">
                <select
                  value={newDailyCategory}
                  onChange={(e) => setNewDailyCategory(e.target.value as 'work' | 'study' | 'personal')}
                  className="px-3 py-2 border rounded-md text-sm"
                >
                  <option value="work">Work</option>
                  <option value="study">Study</option>
                  <option value="personal">Personal</option>
                </select>
                <Button 
                  onClick={addDailyTask} 
                  size="sm"
                  data-testid="button-add-daily-task"
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Today's tasks */}
            <div className="space-y-2">
              {getTodaysTasks().length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">
                  No tasks for today yet
                </p>
              ) : (
                getTodaysTasks().map(task => (
                  <div key={task.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted/50">
                    <Checkbox
                      checked={task.completed}
                      onCheckedChange={() => toggleDailyTask(task.id)}
                      data-testid={`checkbox-task-${task.id}`}
                    />
                    <div className="flex-1">
                      <div className={`text-sm ${task.completed ? 'line-through text-muted-foreground' : ''}`}>
                        {task.title}
                      </div>
                      <Badge className={`${getCategoryColor(task.category)} text-xs mt-1`}>
                        {task.category}
                      </Badge>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deleteDailyTask(task.id)}
                      className="h-6 w-6 p-0"
                      data-testid={`button-delete-task-${task.id}`}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>

        {/* Column 2: Weekly Priorities */}
        <Card className="glass-card">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Target className="h-5 w-5 text-primary" />
              <CardTitle className="text-lg">Weekly Priorities</CardTitle>
            </div>
            <CardDescription>Big 5 goals for this week</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Add new priority form */}
            <div className="space-y-3">
              <Input
                placeholder="Add a weekly priority..."
                value={newWeeklyPriority}
                onChange={(e) => setNewWeeklyPriority(e.target.value)}
                data-testid="input-new-weekly-priority"
              />
              <Textarea
                placeholder="Description (optional)"
                value={newWeeklyDescription}
                onChange={(e) => setNewWeeklyDescription(e.target.value)}
                rows={2}
                data-testid="textarea-weekly-description"
              />
              <Button 
                onClick={addWeeklyPriority} 
                size="sm" 
                className="w-full"
                disabled={getCurrentWeekPriorities().length >= 5}
                data-testid="button-add-weekly-priority"
              >
                <Plus className="h-4 w-4 mr-2" />
                {getCurrentWeekPriorities().length >= 5 ? 'Big 5 Complete!' : 'Add Priority'}
              </Button>
            </div>

            {/* Weekly priorities list */}
            <div className="space-y-3">
              {getCurrentWeekPriorities().length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">
                  No priorities set for this week
                </p>
              ) : (
                getCurrentWeekPriorities().slice(0, 5).map(priority => (
                  <Card key={priority.id} className="p-3">
                    <div className="space-y-2">
                      <div className="flex justify-between items-start">
                        <h4 className="font-medium text-sm">{priority.title}</h4>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteWeeklyPriority(priority.id)}
                          className="h-6 w-6 p-0"
                          data-testid={`button-delete-priority-${priority.id}`}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                      {priority.description && (
                        <p className="text-xs text-muted-foreground">{priority.description}</p>
                      )}
                      <div className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span>Progress</span>
                          <span>{priority.progress}%</span>
                        </div>
                        <div className="flex gap-1">
                          {[0, 25, 50, 75, 100].map(value => (
                            <Button
                              key={value}
                              variant={priority.progress >= value ? "default" : "outline"}
                              size="sm"
                              onClick={() => updatePriorityProgress(priority.id, value)}
                              className="h-6 text-xs flex-1"
                              data-testid={`button-progress-${priority.id}-${value}`}
                            >
                              {value}%
                            </Button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </Card>
                ))
              )}
              {getCurrentWeekPriorities().length >= 5 && (
                <div className="text-center space-y-2">
                  <p className="text-xs text-muted-foreground">
                    🎯 Big 5 Complete! Focus on these priorities
                  </p>
                  <Button 
                    onClick={moveUnfinishedToNextWeek}
                    size="sm"
                    variant="outline"
                    className="w-full text-xs"
                    data-testid="button-move-unfinished"
                  >
                    Move Unfinished to Next Week
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Column 3: Review & Reflect */}
        <Card className="glass-card">
          <CardHeader>
            <div className="flex items-center gap-2">
              <BookOpen className="h-5 w-5 text-primary" />
              <CardTitle className="text-lg">Review & Reflect</CardTitle>
            </div>
            <CardDescription>Weekly reflection and planning</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {weeklyReflection ? (
              <div className="space-y-4">
                <div className="flex items-center gap-2 mb-3">
                  <Star className="h-4 w-4 text-yellow-500" />
                  <span className="text-sm font-medium">Week Reflection Complete</span>
                </div>
                
                <div className="space-y-3 text-sm">
                  <div>
                    <span className="font-medium text-muted-foreground">Accomplishments:</span>
                    <p className="mt-1">{weeklyReflection.accomplishments}</p>
                  </div>
                  
                  <div>
                    <span className="font-medium text-muted-foreground">Challenges:</span>
                    <p className="mt-1">{weeklyReflection.challenges}</p>
                  </div>
                  
                  <div>
                    <span className="font-medium text-muted-foreground">Lessons:</span>
                    <p className="mt-1">{weeklyReflection.lessons}</p>
                  </div>
                  
                  <div>
                    <span className="font-medium text-muted-foreground">Next Week Focus:</span>
                    <p className="mt-1">{weeklyReflection.nextWeekFocus}</p>
                  </div>

                  {weeklyReflection.unfinishedItems.length > 0 && (
                    <div>
                      <span className="font-medium text-muted-foreground">Unfinished Items:</span>
                      <ul className="mt-1 space-y-1">
                        {weeklyReflection.unfinishedItems.map((item, index) => (
                          <li key={index} className="text-xs">• {item}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>

                <div className="flex gap-2">
                  <Button 
                    onClick={() => setWeeklyReflection(null)} 
                    variant="outline" 
                    size="sm"
                    data-testid="button-edit-reflection"
                  >
                    Edit Reflection
                  </Button>
                  {weeklyReflection.unfinishedItems.length > 0 && (
                    <Button 
                      onClick={moveUnfinishedToNextWeek}
                      size="sm"
                      variant="default"
                      data-testid="button-move-unfinished-reflection"
                    >
                      Move to Next Week
                    </Button>
                  )}
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <Textarea
                  placeholder="What did you accomplish this week?"
                  value={reflectionForm.accomplishments}
                  onChange={(e) => setReflectionForm(prev => ({ ...prev, accomplishments: e.target.value }))}
                  rows={2}
                  data-testid="textarea-accomplishments"
                />
                <Textarea
                  placeholder="What challenges did you face?"
                  value={reflectionForm.challenges}
                  onChange={(e) => setReflectionForm(prev => ({ ...prev, challenges: e.target.value }))}
                  rows={2}
                  data-testid="textarea-challenges"
                />
                <Textarea
                  placeholder="What did you learn?"
                  value={reflectionForm.lessons}
                  onChange={(e) => setReflectionForm(prev => ({ ...prev, lessons: e.target.value }))}
                  rows={2}
                  data-testid="textarea-lessons"
                />
                <Textarea
                  placeholder="What should you focus on next week?"
                  value={reflectionForm.nextWeekFocus}
                  onChange={(e) => setReflectionForm(prev => ({ ...prev, nextWeekFocus: e.target.value }))}
                  rows={2}
                  data-testid="textarea-next-week-focus"
                />
                <Button 
                  onClick={saveReflection} 
                  className="w-full"
                  data-testid="button-save-reflection"
                >
                  Save Weekly Reflection
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}