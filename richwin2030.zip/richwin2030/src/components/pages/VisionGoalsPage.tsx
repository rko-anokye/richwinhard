import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Plus, Edit2, Trash2, Target, Calendar, Flag } from "lucide-react";
import { useGoals, Goal } from "@/hooks/useGoals";
import GoalForm from "@/components/forms/GoalForm";

export default function VisionGoalsPage() {
  const { goals, loading, addGoal, updateGoal, deleteGoal } = useGoals();
  const [showForm, setShowForm] = useState(false);
  const [editingGoal, setEditingGoal] = useState<Goal | null>(null);
  const [selectedTimeframe, setSelectedTimeframe] = useState<string>('');

  const timeframes = [
    { value: '1-Year', label: '1-Year Goals', color: 'bg-green-500', icon: '🎯' },
    { value: '3-Year', label: '3-Year Goals', color: 'bg-blue-500', icon: '🚀' },
    { value: '5-Year', label: '5-Year Goals', color: 'bg-purple-500', icon: '🌟' },
    { value: '10-Year', label: '10-Year Legacy', color: 'bg-amber-500', icon: '👑' }
  ];

  const getGoalsByTimeframe = (timeframe: string) => {
    return goals.filter(goal => goal.timeframe === timeframe);
  };

  const handleSubmit = async (goalData: Omit<Goal, 'id' | 'created_at' | 'updated_at'>) => {
    if (editingGoal) {
      await updateGoal(editingGoal.id, goalData);
    } else {
      await addGoal(goalData);
    }
    setShowForm(false);
    setEditingGoal(null);
    setSelectedTimeframe('');
  };

  const handleEdit = (goal: Goal) => {
    setEditingGoal(goal);
    setSelectedTimeframe(goal.timeframe);
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this goal?')) {
      await deleteGoal(id);
    }
  };

  const handleAddGoal = (timeframe: string) => {
    setSelectedTimeframe(timeframe);
    setShowForm(true);
  };

  const getCategoryColor = (category: string) => {
    const colors = {
      'Personal': 'bg-blue-100 text-blue-800',
      'Financial': 'bg-green-100 text-green-800',
      'Relationship': 'bg-pink-100 text-pink-800',
      'Family': 'bg-orange-100 text-orange-800',
      'Business': 'bg-purple-100 text-purple-800',
      'Health': 'bg-red-100 text-red-800',
      'Spiritual': 'bg-yellow-100 text-yellow-800'
    };
    return colors[category as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'in-progress': return 'bg-blue-100 text-blue-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse space-y-4">
          {[1, 2, 3].map(i => (
            <Card key={i} className="glass-card">
              <CardContent className="p-6">
                <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                <div className="h-4 bg-muted rounded w-1/2"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold romantic-heading">Vision & Goals</h1>
        <p className="text-lg text-muted-foreground">Chart your journey toward a shared future</p>
      </div>

      {/* Goal Form */}
      {showForm && (
        <GoalForm
          goal={editingGoal || undefined}
          onSubmit={handleSubmit}
          onCancel={() => {
            setShowForm(false);
            setEditingGoal(null);
            setSelectedTimeframe('');
          }}
          defaultTimeframe={selectedTimeframe}
        />
      )}

      {/* Four Column Layout for Goals */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {timeframes.map(timeframe => {
          const timeframeGoals = getGoalsByTimeframe(timeframe.value);
          return (
            <div key={timeframe.value} className="space-y-4">
              {/* Column Header */}
              <Card className={`glass-card border-2 ${timeframe.color.replace('bg-', 'border-')}/20`}>
                <CardHeader className="text-center pb-4">
                  <div className="flex flex-col items-center gap-3">
                    <div className="text-3xl">{timeframe.icon}</div>
                    <CardTitle className="text-lg text-primary">{timeframe.label}</CardTitle>
                    <Button 
                      onClick={() => handleAddGoal(timeframe.value)}
                      size="sm"
                      className="flex items-center gap-2"
                      data-testid={`button-add-${timeframe.value.toLowerCase()}-goal`}
                    >
                      <Plus className="h-4 w-4" />
                      Add Goal
                    </Button>
                  </div>
                </CardHeader>
              </Card>

              {/* Goals for this timeframe */}
              <div className="space-y-3">
                {timeframeGoals.length === 0 ? (
                  <Card className="glass-card border-dashed">
                    <CardContent className="flex flex-col items-center justify-center py-8">
                      <Target className="h-8 w-8 text-muted-foreground mb-2" />
                      <p className="text-sm text-muted-foreground text-center">
                        No goals set yet
                      </p>
                    </CardContent>
                  </Card>
                ) : (
                  timeframeGoals.map(goal => (
                    <Card key={goal.id} className="glass-card hover:shadow-romantic transition-all duration-300">
                      <CardContent className="p-4 space-y-3">
                        <div className="flex justify-between items-start">
                          <h4 className="font-semibold text-sm leading-tight flex-1">{goal.title}</h4>
                          <div className="flex gap-1 ml-2">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => handleEdit(goal)}
                              className="h-7 w-7 p-0"
                              data-testid={`button-edit-goal-${goal.id}`}
                            >
                              <Edit2 className="h-3 w-3" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => handleDelete(goal.id)}
                              className="h-7 w-7 p-0 hover:bg-destructive/10 hover:text-destructive"
                              data-testid={`button-delete-goal-${goal.id}`}
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>

                        {goal.category && (
                          <Badge className={`${getCategoryColor(goal.category)} text-xs`}>
                            {goal.category}
                          </Badge>
                        )}

                        {goal.description && (
                          <p className="text-xs text-muted-foreground leading-relaxed">{goal.description}</p>
                        )}

                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-xs font-medium">Progress</span>
                            <span className="text-xs text-muted-foreground">{goal.progress}%</span>
                          </div>
                          <Progress value={goal.progress} className="h-1.5" />
                        </div>

                        {goal.deadline && (
                          <div className="flex items-center gap-1 text-xs text-muted-foreground">
                            <Calendar className="h-3 w-3" />
                            Due: {new Date(goal.deadline).toLocaleDateString()}
                          </div>
                        )}

                        {goal.milestones.length > 0 && (
                          <div className="space-y-1">
                            <div className="flex items-center gap-1">
                              <Flag className="h-3 w-3" />
                              <span className="text-xs font-medium">Milestones</span>
                            </div>
                            <div className="space-y-1 max-h-20 overflow-y-auto">
                              {goal.milestones.slice(0, 2).map((milestone, index) => (
                                <div key={index} className="text-xs text-muted-foreground pl-4">
                                  • {milestone}
                                </div>
                              ))}
                              {goal.milestones.length > 2 && (
                                <div className="text-xs text-muted-foreground pl-4">
                                  +{goal.milestones.length - 2} more...
                                </div>
                              )}
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}